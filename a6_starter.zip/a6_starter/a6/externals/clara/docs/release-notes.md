<a id="top"></a>

# 1.1.3

## Improvements
* `Args` now take arguments as `int argc, char const * const * argv`.
  * This allows the use of string literals for arguments


# 1.1.2
* Fix usage of `dynamic_cast` preventing Clara being used with `-fno-rtti`


# Older versions (1.1.1 and earlier)

No release notes have been kept (Maybe some of it will be backfilled later)
